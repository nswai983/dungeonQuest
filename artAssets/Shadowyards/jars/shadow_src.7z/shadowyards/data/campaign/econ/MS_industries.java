package data.campaign.econ;

public class MS_industries {
    public static final String MODULARFACTORIES = "ms_modularFac";
    public static final String PARALLEL_PRODUCTION = "ms_massIndustry";
    public static final String MILITARY_LINES = "ms_militaryProduction";
    public static final String SHIPYARDS = "ms_orbitalShipyard";
    public static final String SOLAR = "ms_supersolar";
    public static final String MEDICALCENTER = "ms_medCenter";
    public static final String RADBLOCKERS = "ms_radiationAbsorbers";
    
    public static final String ORBITAL1 = "ms_orbitalstation";
    public static final String ORBITAL2 = "ms_battlestation";
    public static final String ORBITAL3 = "ms_starfortress";
}
